SUZY FINAL COLORING ASSETS

- dino_outline.png / dino_mask.png
- lion_outline.png / lion_mask.png
- elephant_outline.png / elephant_mask.png
- monkey_outline.png / monkey_mask.png

Mask Fix Applied:
✔ Alpha-only masks (alpha=255)
✔ Ignore RGB in hit-test
✔ Use minAlpha 60–80, tol 0–2
